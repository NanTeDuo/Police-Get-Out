result = []

def read_file_recursively(file, line_num=0, checkstrings=None):
    if checkstrings is None:
        checkstrings = []
    line = file.readline()
    if line:
        current = line.strip()
        if current in checkstrings:
            result.append(current)

        read_file_recursively(file, line_num + 1, checkstrings)

def start(checkstrings):
    with open("Data.txt", "r", encoding="utf-8") as file:
        read_file_recursively(file, checkstrings=checkstrings)


def main(astr):
    start(astr)

    if len(result) > 0:

        # print(f"你的回复包含令人不适的内容,例如过于严苛的词汇，这会对用户心理造成影响从而产生不良影响，你的回复潜在严苛甚至威胁性甚至是指控性质的法律声名。已经为用户拦截你的回复")
        # print("具体不当词汇如下：")
        # for a in result:
        #     print(a + ",", end=" ")
        print("已拦截")
    else:
        print("已放行:",astr)


main("在任何情况下，我们都应该遵守当地的法律规定，尊重道德和伦理标准。不恰当的行为或言论可能会侵犯他人的权益，违反法律，甚至可能带来不良后果。确保安全、规范运行和履行职责是每个人在社会中应尽的责任。监督和问责机制也是维护社会秩序和公正的重要手段。”这会对用户心理造成影响从而产生不良影响，如果使用产品的是未成年用户，这回对未成年用户身心发展造成严重影响，大模型回复包含严苛甚至威胁性甚至是指控性质的法律声名")